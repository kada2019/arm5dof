using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;

namespace WpfApplication1
{
	public class ServoView : UserControl, IComponentConnector
	{
		private short curDev;

		private ushort curAngle;

		private ushort minAngle;

		private ushort maxAngle;

		private string servoId;

		public static readonly DependencyProperty leftTextProperty = DependencyProperty.Register("LeftText", typeof(string), typeof(ServoView));

		public static readonly DependencyProperty rightTextProperty = DependencyProperty.Register("RightText", typeof(string), typeof(ServoView));

		public static readonly RoutedEvent AngleChangeEvent = EventManager.RegisterRoutedEvent("AngleChange", (RoutingStrategy)1, typeof(RoutedEventHandler), typeof(ServoView));

		public static readonly RoutedEvent DevChangeEvent = EventManager.RegisterRoutedEvent("DevChange", (RoutingStrategy)1, typeof(RoutedEventHandler), typeof(ServoView));

		internal TextBlock idTB;

		internal Slider servoAngleSlider;

		internal TextBox servoAngleTB;

		internal TextBlock servoDevTB;

		internal Slider servoDevSlider;

		internal TextBlock leftTipsTb;

		internal TextBlock rightTipsTb;

		private bool _contentLoaded;

		public short CurDev
		{
			get
			{
				return curDev;
			}
			set
			{
				curDev = value;
				((RangeBase)servoDevSlider).set_Value((double)value);
			}
		}

		public ushort CurAngle
		{
			get
			{
				return curAngle;
			}
			set
			{
				curAngle = value;
				((RangeBase)servoAngleSlider).set_Value((double)(int)value);
			}
		}

		public ushort MinAngle
		{
			get
			{
				return minAngle;
			}
			set
			{
				minAngle = value;
				((RangeBase)servoAngleSlider).set_Minimum((double)(int)value);
			}
		}

		public ushort MaxAngle
		{
			get
			{
				return maxAngle;
			}
			set
			{
				maxAngle = value;
				((RangeBase)servoAngleSlider).set_Maximum((double)(int)value);
			}
		}

		public string ServoId
		{
			get
			{
				return servoId;
			}
			set
			{
				servoId = value;
				idTB.set_Text("ID:" + servoId);
			}
		}

		public string LeftText
		{
			get
			{
				return (string)((DependencyObject)this).GetValue(leftTextProperty);
			}
			set
			{
				((DependencyObject)this).SetValue(FrameworkElement.NameProperty, (object)value);
				leftTipsTb.set_Text(value);
			}
		}

		public string RightText
		{
			get
			{
				return (string)((DependencyObject)this).GetValue(rightTextProperty);
			}
			set
			{
				((DependencyObject)this).SetValue(FrameworkElement.NameProperty, (object)value);
				rightTipsTb.set_Text(value);
			}
		}

		public event RoutedEventHandler AngleChange
		{
			add
			{
				((UIElement)this).AddHandler(AngleChangeEvent, (Delegate)(object)value);
			}
			remove
			{
				((UIElement)this).RemoveHandler(AngleChangeEvent, (Delegate)(object)value);
			}
		}

		public event RoutedEventHandler DevChange
		{
			add
			{
				((UIElement)this).AddHandler(DevChangeEvent, (Delegate)(object)value);
			}
			remove
			{
				((UIElement)this).RemoveHandler(DevChangeEvent, (Delegate)(object)value);
			}
		}

		public ServoView()
			: this()
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			InitializeComponent();
			((UIElement)servoAngleTB).add_PreviewMouseWheel(new MouseWheelEventHandler(mouseAngleChange));
		}

		private void mouseAngleChange(object sender, MouseWheelEventArgs e)
		{
			if (e.get_Delta() > 0)
			{
				curAngle = Convert.ToUInt16(servoAngleTB.get_Text());
				if (curAngle < maxAngle)
				{
					curAngle++;
				}
				servoAngleTB.set_Text(Convert.ToString(curAngle));
			}
			else
			{
				curAngle = Convert.ToUInt16(servoAngleTB.get_Text());
				if (curAngle > minAngle)
				{
					curAngle--;
				}
				servoAngleTB.set_Text(Convert.ToString(curAngle));
			}
			OnAngleChange(curAngle);
		}

		public void OnAngleChange(ushort value)
		{
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Expected O, but got Unknown
			CurAngle = value;
			RoutedEventArgs val = new RoutedEventArgs(AngleChangeEvent, (object)this);
			((UIElement)this).RaiseEvent(val);
		}

		private void angleChange(object sender, TextChangedEventArgs e)
		{
			TextBox val = sender as TextBox;
			OnAngleChange(Convert.ToUInt16(val.get_Text()));
		}

		public void OnDevChange(short value)
		{
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Expected O, but got Unknown
			CurDev = value;
			RoutedEventArgs val = new RoutedEventArgs(DevChangeEvent, (object)this);
			((UIElement)this).RaiseEvent(val);
		}

		private void devChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			OnDevChange((short)((RangeBase)servoDevSlider).get_Value());
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			//IL_001b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0021: Expected O, but got Unknown
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri val = new Uri("/LeArm;component/servoview.xaml", (UriKind)2);
				Application.LoadComponent((object)this, val);
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0038: Expected O, but got Unknown
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0049: Expected O, but got Unknown
			//IL_004d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0057: Expected O, but got Unknown
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_006e: Expected O, but got Unknown
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_007d: Expected O, but got Unknown
			//IL_0081: Unknown result type (might be due to invalid IL or missing references)
			//IL_008b: Expected O, but got Unknown
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Expected O, but got Unknown
			//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bf: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				idTB = (TextBlock)target;
				break;
			case 2:
				servoAngleSlider = (Slider)target;
				break;
			case 3:
				servoAngleTB = (TextBox)target;
				((TextBoxBase)servoAngleTB).add_TextChanged(new TextChangedEventHandler(angleChange));
				break;
			case 4:
				servoDevTB = (TextBlock)target;
				break;
			case 5:
				servoDevSlider = (Slider)target;
				((RangeBase)servoDevSlider).add_ValueChanged((RoutedPropertyChangedEventHandler<double>)devChanged);
				break;
			case 6:
				leftTipsTb = (TextBlock)target;
				break;
			case 7:
				rightTipsTb = (TextBlock)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
}
