using System.Globalization;
using System.Windows.Controls;

namespace WpfApplication1
{
	internal class RangeAngleValidation : ValidationRule
	{
		public override ValidationResult Validate(object value, CultureInfo cultureInfo)
		{
			//IL_0042: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Expected O, but got Unknown
			//IL_0051: Unknown result type (might be due to invalid IL or missing references)
			//IL_0057: Expected O, but got Unknown
			double result = 0.0;
			if (double.TryParse(value.ToString(), out result) && result >= 500.0 && result <= 2500.0)
			{
				return new ValidationResult(true, (object)null);
			}
			return new ValidationResult(false, (object)"Validation Failed");
		}

		public RangeAngleValidation()
			: this()
		{
		}
	}
}
