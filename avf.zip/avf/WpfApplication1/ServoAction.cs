using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;

namespace WpfApplication1
{
	internal class ServoAction : INotifyPropertyChanged
	{
		private string indexPath;

		private ushort servoTime;

		private int itemID;

		private List<ushort> servoAngles = new List<ushort>();

		public ushort ServoTime
		{
			get
			{
				return servoTime;
			}
			set
			{
				//IL_0022: Unknown result type (might be due to invalid IL or missing references)
				//IL_002c: Expected O, but got Unknown
				servoTime = value;
				if ((object)this.PropertyChanged != null)
				{
					this.PropertyChanged.Invoke((object)this, new PropertyChangedEventArgs("ServoTime"));
				}
			}
		}

		public string IndexPath
		{
			get
			{
				return indexPath;
			}
			set
			{
				//IL_0022: Unknown result type (might be due to invalid IL or missing references)
				//IL_002c: Expected O, but got Unknown
				indexPath = value;
				if ((object)this.PropertyChanged != null)
				{
					this.PropertyChanged.Invoke((object)this, new PropertyChangedEventArgs("IndexPath"));
				}
			}
		}

		public List<ushort> ServoAngles
		{
			get
			{
				return servoAngles;
			}
			set
			{
				//IL_0022: Unknown result type (might be due to invalid IL or missing references)
				//IL_002c: Expected O, but got Unknown
				servoAngles = value;
				if ((object)this.PropertyChanged != null)
				{
					this.PropertyChanged.Invoke((object)this, new PropertyChangedEventArgs("ServoAngles"));
				}
			}
		}

		public int ItemID
		{
			get
			{
				return itemID;
			}
			set
			{
				//IL_0022: Unknown result type (might be due to invalid IL or missing references)
				//IL_002c: Expected O, but got Unknown
				itemID = value;
				if ((object)this.PropertyChanged != null)
				{
					this.PropertyChanged.Invoke((object)this, new PropertyChangedEventArgs("ItemID"));
				}
			}
		}

		public event PropertyChangedEventHandler PropertyChanged
		{
			[CompilerGenerated]
			add
			{
				//IL_0010: Unknown result type (might be due to invalid IL or missing references)
				//IL_0016: Expected O, but got Unknown
				PropertyChangedEventHandler val = this.PropertyChanged;
				PropertyChangedEventHandler val2;
				do
				{
					val2 = val;
					PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Combine((Delegate?)(object)val2, (Delegate?)(object)value);
					val = Interlocked.CompareExchange(ref System.Runtime.CompilerServices.Unsafe.As<PropertyChangedEventHandler, PropertyChangedEventHandler>(ref this.PropertyChanged), value2, val2);
				}
				while (val != val2);
			}
			[CompilerGenerated]
			remove
			{
				//IL_0010: Unknown result type (might be due to invalid IL or missing references)
				//IL_0016: Expected O, but got Unknown
				PropertyChangedEventHandler val = this.PropertyChanged;
				PropertyChangedEventHandler val2;
				do
				{
					val2 = val;
					PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Remove((Delegate?)(object)val2, (Delegate?)(object)value);
					val = Interlocked.CompareExchange(ref System.Runtime.CompilerServices.Unsafe.As<PropertyChangedEventHandler, PropertyChangedEventHandler>(ref this.PropertyChanged), value2, val2);
				}
				while (val != val2);
			}
		}
	}
}
