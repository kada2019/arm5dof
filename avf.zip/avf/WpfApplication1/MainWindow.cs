using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Dongzr.MidiLite;
using Microsoft.Win32;
using Synoxo.USBHidDevice;

namespace WpfApplication1
{
	public class MainWindow : Window, IComponentConnector
	{
		private bool needSendAngelChangeFlag = true;

		private bool needSendDevChangeFlag = true;

		public const int MAX_ACTION_ITEMS = 1020;

		public const int CMD_MULT_SERVO_MOVE = 3;

		public const int CMD_ACTION_DOWNLOAD = 5;

		public const int CMD_FULL_ACTION_RUN = 6;

		public const int CMD_FULL_ACTION_STOP = 7;

		public const int CMD_FULL_ACTION_ERASE = 8;

		public const int CMD_SERVO_OFFSET_WRITE = 12;

		public const int CMD_SERVO_OFFSET_READ = 13;

		public const int CMD_SERVO_OFFSET_ADJUST = 14;

		public const int WAIT_SHORT = 200;

		public const int WAIT_NORMAL = 300;

		public const int WATI_LONG = 800;

		public const int SINGLE_ITEM_BYTES = 194;

		public const int SERVO_NUM = 6;

		public const int MAX_ARGS_LENTH = 50;

		public const ushort UNDEFINECMD = 65280;

		private ObservableCollection<ServoAction> m_ServoActions = new ObservableCollection<ServoAction>();

		private ObservableCollection<string> actionNumList = new ObservableCollection<string>();

		private List<string> languageList = new List<string>();

		private static int myVendorID = 1155;

		private static int myProductID = 22352;

		private static int myVersion = 513;

		private DeviceManagement MyDeviceManagement = new DeviceManagement(myVendorID, myProductID, myVersion);

		private List<ServoView> servosViewList = new List<ServoView>();

		private bool connectStatus = false;

		private Stopwatch stopWatch = new Stopwatch();

		private bool runningOnline = false;

		private readonly TaskScheduler _syncContextTaskScheduler = TaskScheduler.FromCurrentSynchronizationContext();

		private int curRunId = 0;

		private static MmTimer _1msTimer;

		private ushort editAngle;

		private int editIndex;

		private int editRow;

		private static DispatcherTimer readDataTimer = new DispatcherTimer();

		private bool needSave = false;

		private uint needSaveCnt = 0u;

		private int needReadDev = 0;

		private bool readDevStart = false;

		private int readDevStartCnt = 0;

		internal DataGrid actionList;

		internal Canvas servosView;

		internal ComboBox lanSetComBox;

		internal Image connectImag;

		internal ServoView servo1;

		internal ServoView servo2;

		internal ServoView servo3;

		internal ServoView servo4;

		internal ServoView servo5;

		internal ServoView servo6;

		internal TextBlock releaseTips;

		internal TextBlock closeTips;

		internal TextBlock forwardTips;

		internal TextBlock backwardTips;

		internal TextBlock downTips;

		internal TextBlock upTips;

		internal TextBlock leftTips;

		internal TextBlock rightTips;

		internal TextBox actTimeTX;

		internal Button addActionBtn;

		internal Button deleteActionBtn;

		internal Button updateActionBtn;

		internal Button insertActionBtn;

		internal TextBlock saveFileTB;

		internal TranslateTransform tipsTranslate;

		internal TextBlock filePathTB;

		internal Button readDevBtn;

		internal Button downloadDevBtn;

		internal Button resetDevBtn;

		internal CheckBox loopCheck;

		internal Image runonlineImag;

		internal Button openFileBtn;

		internal Button saveFileBtn;

		internal Button integrateBtn;

		internal ComboBox actionGroupCombox;

		internal Button downloadBtn;

		private bool _contentLoaded;

		public MainWindow()
			: this()
		{
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0049: Expected O, but got Unknown
			//IL_005c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0066: Expected O, but got Unknown
			//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cd: Expected O, but got Unknown
			//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ea: Expected O, but got Unknown
			//IL_011c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0126: Expected O, but got Unknown
			//IL_0261: Unknown result type (might be due to invalid IL or missing references)
			//IL_026b: Expected O, but got Unknown
			//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
			//IL_02c5: Expected O, but got Unknown
			InitializeComponent();
			((UIElement)servosView).AddHandler(ServoView.AngleChangeEvent, (Delegate)new RoutedEventHandler(angleChangeHandler));
			((UIElement)servosView).AddHandler(ServoView.DevChangeEvent, (Delegate)new RoutedEventHandler(devChangeHandler));
			((ItemsControl)actionList).set_ItemsSource((IEnumerable)m_ServoActions);
			((ItemsControl)actionGroupCombox).set_ItemsSource((IEnumerable)actionNumList);
			((UIElement)actTimeTX).add_PreviewMouseWheel(new MouseWheelEventHandler(actionTimeChange));
			for (int i = 0; i <= 230; i++)
			{
				((Collection<string>)(object)actionNumList).Add(Convert.ToString(i));
			}
			languageList.Add("arabic");
			languageList.Add("繁體");
			languageList.Add("English");
			((ItemsControl)lanSetComBox).set_ItemsSource((IEnumerable)languageList);
			string name = CultureInfo.CurrentCulture.Name;
			if (name.Contains("zh-CN"))
			{
				((Selector)lanSetComBox).set_SelectedIndex(0);
				name = "zh-CN";
			}
			else if (name.Contains("zh-TW") || name.Contains("zh-HK"))
			{
				((Selector)lanSetComBox).set_SelectedIndex(1);
				name = "zh-TW";
			}
			else
			{
				((Selector)lanSetComBox).set_SelectedIndex(2);
				name = "DefaultLanguage";
				((UIElement)downTips).set_Visibility((Visibility)0);
				((UIElement)upTips).set_Visibility((Visibility)0);
				((UIElement)leftTips).set_Visibility((Visibility)0);
				((UIElement)rightTips).set_Visibility((Visibility)0);
			}
			ResourceDictionary val = null;
			object obj = Application.LoadComponent(new Uri("Language\\" + name + ".xaml", (UriKind)2));
			val = obj as ResourceDictionary;
			if (val != null)
			{
				if (((FrameworkElement)this).get_Resources().get_MergedDictionaries().Count > 0)
				{
					((FrameworkElement)this).get_Resources().get_MergedDictionaries().Clear();
				}
				((FrameworkElement)this).get_Resources().get_MergedDictionaries().Add(val);
			}
			_1msTimer = new MmTimer();
			_1msTimer.set_Mode((MmTimerMode)1);
			_1msTimer.set_Interval(1);
			_1msTimer.add_Tick((EventHandler)runOnlineHandler);
			updateServoText();
			servosViewList.Add(servo1);
			servosViewList.Add(servo2);
			servosViewList.Add(servo3);
			servosViewList.Add(servo4);
			servosViewList.Add(servo5);
			servosViewList.Add(servo6);
			((Selector)actionGroupCombox).set_SelectedIndex(0);
			initUsbCommunication();
			readDataTimer.add_Tick((EventHandler)timeCycle);
			readDataTimer.set_Interval(new TimeSpan(0, 0, 0, 1));
			readDataTimer.Start();
			showSaveTips();
		}

		private void updateServoText()
		{
			servo1.LeftText = ((FrameworkElement)this).TryFindResource((object)"relkadaease") as string;
			servo1.RightText = ((FrameworkElement)this).TryFindResource((object)"cloffse") as string;
			servo2.LeftText = ((FrameworkElement)this).TryFindResource((object)"turffn_left") as string;
			servo2.RightText = ((FrameworkElement)this).TryFindResource((object)"tuffrn_right") as string;
			servo3.LeftText = ((FrameworkElement)this).TryFindResource((object)"dowffn") as string;
			servo3.RightText = ((FrameworkElement)this).TryFindResource((object)"upff") as string;
			servo4.LeftText = ((FrameworkElement)this).TryFindResource((object)"forffward") as string;
			servo4.RightText = ((FrameworkElement)this).TryFindResource((object)"bacffkward") as string;
			servo5.LeftText = ((FrameworkElement)this).TryFindResource((object)"backffward") as string;
			servo5.RightText = ((FrameworkElement)this).TryFindResource((object)"forwffard") as string;
			servo6.LeftText = ((FrameworkElement)this).TryFindResource((object)"riffght") as string;
			servo6.RightText = ((FrameworkElement)this).TryFindResource((object)"leffft") as string;
		}

		private void initUsbCommunication()
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0018: Expected O, but got Unknown
			//IL_004b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0055: Expected O, but got Unknown
			//IL_0050: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Expected O, but got Unknown
			//IL_0072: Unknown result type (might be due to invalid IL or missing references)
			//IL_007c: Expected O, but got Unknown
			//IL_0077: Unknown result type (might be due to invalid IL or missing references)
			//IL_0081: Expected O, but got Unknown
			MyDeviceManagement.add_WhenUsbEvent(new usbEventsHandler(MyDeviceManagement_WhenUsbEvent));
			if (MyDeviceManagement.findHidDevices(ref myVendorID, ref myProductID, ref myVersion))
			{
				connectStatus = true;
				connectImag.set_Source((ImageSource)new BitmapImage(new Uri("/Resources/connect.png", (UriKind)2)));
			}
			else
			{
				connectStatus = false;
				connectImag.set_Source((ImageSource)new BitmapImage(new Uri("/Resources/disconnect.png", (UriKind)2)));
			}
		}

		private void MyDeviceManagement_WhenUsbEvent(object sender, USBEventArgs e)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_000f: Invalid comparison between Unknown and I4
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0046: Expected O, but got Unknown
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			//IL_004b: Expected O, but got Unknown
			//IL_0084: Unknown result type (might be due to invalid IL or missing references)
			//IL_008e: Expected O, but got Unknown
			//IL_0089: Unknown result type (might be due to invalid IL or missing references)
			//IL_0093: Expected O, but got Unknown
			USBDeviceStateEnum status = e.Status;
			if ((int)status != 0)
			{
				if ((int)status == 1 && isLobotDevice(e))
				{
					connectStatus = false;
					if (needReadDev == 2)
					{
						readDevStart = true;
					}
					connectImag.set_Source((ImageSource)new BitmapImage(new Uri("/Resources/disconnect.png", (UriKind)2)));
				}
			}
			else if (isLobotDevice(e))
			{
				readDevStart = false;
				connectStatus = true;
				connectImag.set_Source((ImageSource)new BitmapImage(new Uri("/Resources/connect.png", (UriKind)2)));
			}
		}

		private bool isLobotDevice(USBEventArgs e)
		{
			bool result = false;
			if (MyDeviceManagement.get_Item(e.DeviceIndex).DeviceAttributes.ProductID == myProductID && MyDeviceManagement.get_Item(e.DeviceIndex).DeviceAttributes.VendorID == myVendorID && MyDeviceManagement.get_Item(e.DeviceIndex).DeviceAttributes.VersionNumber == myVersion)
			{
				result = true;
			}
			return result;
		}

		private void actionTimeChange(object sender, MouseWheelEventArgs e)
		{
			int num = Convert.ToInt32(actTimeTX.get_Text());
			if (e.get_Delta() > 0)
			{
				if (num < 30000)
				{
					num++;
					actTimeTX.set_Text(Convert.ToString(num));
				}
			}
			else if (num > 0)
			{
				num--;
				actTimeTX.set_Text(Convert.ToString(num));
			}
		}

		private void angleChangeHandler(object sender, RoutedEventArgs e)
		{
			if (needSendAngelChangeFlag)
			{
				int id = Convert.ToInt32((e.get_OriginalSource() as ServoView).ServoId);
				int curAngle = (e.get_OriginalSource() as ServoView).CurAngle;
				if (connectStatus)
				{
					sendAngleCmd(id, curAngle);
				}
			}
		}

		private void devChangeHandler(object sender, RoutedEventArgs e)
		{
			//IL_003e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Invalid comparison between Unknown and I4
			if (!needSendDevChangeFlag)
			{
				return;
			}
			if (needReadDev == 0)
			{
				needReadDev = 1;
				string text = ((FrameworkElement)this).TryFindResource((object)"read_dev_first") as string;
				if ((int)MessageBox.Show(text, "Confirmation", (MessageBoxButton)4) == 6)
				{
					doReadDev();
				}
			}
			else
			{
				int id = Convert.ToInt32((e.get_OriginalSource() as ServoView).ServoId);
				int curDev = (e.get_OriginalSource() as ServoView).CurDev;
				if (connectStatus)
				{
					sendSingleAngleCmd(id, curDev + (e.get_OriginalSource() as ServoView).CurAngle);
				}
			}
		}

		private void onCellChange(object sender, EventArgs e)
		{
			//IL_008d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0092: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
			DataGrid val = sender as DataGrid;
			ServoAction servoAction = val.get_CurrentItem() as ServoAction;
			if (servoAction == null)
			{
				return;
			}
			for (int i = 0; i < ((Collection<ServoAction>)(object)m_ServoActions).Count; i++)
			{
				((Collection<ServoAction>)(object)m_ServoActions)[i].IndexPath = null;
			}
			if (((Collection<ServoAction>)(object)m_ServoActions).Count >= servoAction.ItemID)
			{
				((Collection<ServoAction>)(object)m_ServoActions)[servoAction.ItemID - 1].IndexPath = "/Resources/index.png";
			}
			DataGridCellInfo currentCell = val.get_CurrentCell();
			if (((DataGridCellInfo)(ref currentCell)).get_Column() != null)
			{
				currentCell = val.get_CurrentCell();
				if (((DataGridCellInfo)(ref currentCell)).get_Column().get_DisplayIndex() == 0)
				{
					runAtCurrentItem(servoAction.ItemID - 1);
				}
			}
		}

		private void editAngleBegin(object sender, DataGridBeginningEditEventArgs e)
		{
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Unknown result type (might be due to invalid IL or missing references)
			//IL_0068: Unknown result type (might be due to invalid IL or missing references)
			DataGrid val = sender as DataGrid;
			DataGridCellInfo currentCell = val.get_CurrentCell();
			if (((DataGridCellInfo)(ref currentCell)).get_Column().get_DisplayIndex() >= 3)
			{
				currentCell = val.get_CurrentCell();
				editRow = (((DataGridCellInfo)(ref currentCell)).get_Item() as ServoAction).ItemID - 1;
				currentCell = val.get_CurrentCell();
				editIndex = ((DataGridCellInfo)(ref currentCell)).get_Column().get_DisplayIndex() - 3;
				currentCell = val.get_CurrentCell();
				editAngle = (((DataGridCellInfo)(ref currentCell)).get_Item() as ServoAction).ServoAngles[editIndex];
			}
		}

		private void editAngleEnd(object sender, DataGridCellEditEndingEventArgs e)
		{
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00af: Unknown result type (might be due to invalid IL or missing references)
			DataGrid val = sender as DataGrid;
			FrameworkElement editingElement = e.get_EditingElement();
			TextBox val2 = editingElement as TextBox;
			DataGridCellInfo currentCell = val.get_CurrentCell();
			int num;
			if (((DataGridCellInfo)(ref currentCell)).get_Column() != null)
			{
				currentCell = val.get_CurrentCell();
				num = ((((DataGridCellInfo)(ref currentCell)).get_Column().get_DisplayIndex() >= 3) ? 1 : 0);
			}
			else
			{
				num = 0;
			}
			if (num != 0 && (Convert.ToUInt16(val2.get_Text()) > 2500 || Convert.ToUInt16(val2.get_Text()) < 500))
			{
				((Collection<ServoAction>)(object)m_ServoActions)[editRow].ServoAngles[editIndex] = editAngle;
				string text = ((FrameworkElement)this).TryFindResource((object)"input_angle_erro") as string;
				MessageBox.Show(text);
			}
		}

		private void addAction(object sender, RoutedEventArgs e)
		{
			doAddAction(((Collection<ServoAction>)(object)m_ServoActions).Count);
		}

		private void deleteAction(object sender, RoutedEventArgs e)
		{
			needSave = true;
			int selectedIndex = ((Selector)actionList).get_SelectedIndex();
			if (selectedIndex == -1)
			{
				return;
			}
			((Collection<ServoAction>)(object)m_ServoActions).RemoveAt(selectedIndex);
			if (((Collection<ServoAction>)(object)m_ServoActions).Count > 0)
			{
				if (selectedIndex == ((Collection<ServoAction>)(object)m_ServoActions).Count)
				{
					setActionListSelectRow(((Collection<ServoAction>)(object)m_ServoActions).Count - 1);
				}
				else
				{
					setActionListSelectRow(selectedIndex);
				}
				resetItemId();
			}
		}

		private void updateAction(object sender, RoutedEventArgs e)
		{
			needSave = true;
			int selectedIndex = ((Selector)actionList).get_SelectedIndex();
			if (selectedIndex != -1)
			{
				List<ushort> list = new List<ushort>();
				for (int i = 0; i < servosViewList.Count; i++)
				{
					list.Add(servosViewList[i].CurAngle);
				}
				((Collection<ServoAction>)(object)m_ServoActions)[selectedIndex].ServoAngles = list;
				((Collection<ServoAction>)(object)m_ServoActions)[selectedIndex].ServoTime = Convert.ToUInt16(actTimeTX.get_Text());
			}
		}

		private void insertAction(object sender, RoutedEventArgs e)
		{
			int selectedIndex = ((Selector)actionList).get_SelectedIndex();
			if (selectedIndex != -1)
			{
				doAddAction(selectedIndex);
			}
			else
			{
				doAddAction(((Collection<ServoAction>)(object)m_ServoActions).Count);
			}
			resetItemId();
		}

		private void resetItemId()
		{
			for (int i = 0; i < ((Collection<ServoAction>)(object)m_ServoActions).Count; i++)
			{
				((Collection<ServoAction>)(object)m_ServoActions)[i].ItemID = i + 1;
			}
		}

		private void doAddAction(int item)
		{
			//IL_0031: Unknown result type (might be due to invalid IL or missing references)
			needSave = true;
			if (((Collection<ServoAction>)(object)m_ServoActions).Count > 1020)
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"actions_max_tips") as string;
				MessageBox.Show(text);
				return;
			}
			ServoAction servoAction = new ServoAction();
			servoAction.ServoTime = Convert.ToUInt16(actTimeTX.get_Text());
			servoAction.ItemID = item + 1;
			List<ushort> list = new List<ushort>();
			for (int i = 0; i < servosViewList.Count; i++)
			{
				list.Add(servosViewList[i].CurAngle);
			}
			servoAction.ServoAngles = list;
			((Collection<ServoAction>)(object)m_ServoActions).Insert(item, servoAction);
			setActionListSelectRow(item);
		}

		private void setActionListSelectRow(int index)
		{
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0018: Expected O, but got Unknown
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0061: Expected O, but got Unknown
			DataGridRow val = (DataGridRow)((ItemsControl)actionList).get_ItemContainerGenerator().ContainerFromIndex(index);
			if (val == null)
			{
				((UIElement)actionList).UpdateLayout();
				actionList.ScrollIntoView(((ItemsControl)actionList).get_Items().get_Item(index));
				val = (DataGridRow)((ItemsControl)actionList).get_ItemContainerGenerator().ContainerFromIndex(index);
				if (val != null)
				{
					val.set_IsSelected(true);
				}
			}
			else
			{
				((UIElement)actionList).UpdateLayout();
				actionList.ScrollIntoView(((ItemsControl)actionList).get_Items().get_Item(index));
				val.set_IsSelected(true);
			}
			for (int i = 0; i < ((Collection<ServoAction>)(object)m_ServoActions).Count; i++)
			{
				((Collection<ServoAction>)(object)m_ServoActions)[i].IndexPath = null;
			}
			((Collection<ServoAction>)(object)m_ServoActions)[index].IndexPath = "/Resources/index.png";
		}

		private void sendAngleCmd(int id, int value)
		{
			ushort[] array = new ushort[50];
			for (int i = 0; i < 50; i++)
			{
				array[i] = 65280;
			}
			array[0] = 1;
			array[1] = 0;
			array[2] = 0;
			array[3] = (byte)id;
			array[4] = (byte)((uint)value & 0xFFu);
			array[5] = (byte)(value >> 8);
			makeAndSendCmd(3, array);
		}

		private void sendActionAngleCmd(int index)
		{
			ushort[] array = new ushort[50];
			for (int i = 0; i < 50; i++)
			{
				array[i] = 65280;
			}
			array[0] = 6;
			array[1] = (byte)(((Collection<ServoAction>)(object)m_ServoActions)[index].ServoTime & 0xFFu);
			array[2] = (byte)((uint)(((Collection<ServoAction>)(object)m_ServoActions)[index].ServoTime >> 8) & 0xFFu);
			for (int j = 0; j < 6; j++)
			{
				array[3 + 3 * j] = (byte)(j + 1);
				array[4 + 3 * j] = (byte)(((Collection<ServoAction>)(object)m_ServoActions)[index].ServoAngles[j] & 0xFFu);
				array[5 + 3 * j] = (byte)((uint)(((Collection<ServoAction>)(object)m_ServoActions)[index].ServoAngles[j] >> 8) & 0xFFu);
				servosViewList[j].CurAngle = ((Collection<ServoAction>)(object)m_ServoActions)[index].ServoAngles[j];
			}
			makeAndSendCmd(3, array);
		}

		private void sendSingleAngleCmd(int id, int value)
		{
			ushort[] array = new ushort[50];
			for (int i = 0; i < 50; i++)
			{
				array[i] = 65280;
			}
			array[0] = (byte)id;
			array[1] = (byte)((uint)value & 0xFFu);
			array[2] = (byte)(value >> 8);
			makeAndSendCmd(14, array);
		}

		private void makeAndSendCmd(int cmdType, ushort[] args)
		{
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			if (connectStatus)
			{
				byte[] array = new byte[getBufferLength(args) + 4];
				array[0] = 85;
				array[1] = 85;
				array[3] = (byte)cmdType;
				byte[] array2 = new byte[16];
				int i;
				for (i = 0; args[i] != 65280; i++)
				{
					array[4 + i] = (byte)args[i];
				}
				byte b = (array[2] = (byte)(i + 2));
				if (!MyDeviceManagement.InputAndOutputReports(0, false, array, ref array2, 300))
				{
					string text = ((FrameworkElement)this).TryFindResource((object)"send_fail") as string;
					MessageBox.Show(text);
				}
			}
		}

		private int getBufferLength(ushort[] args)
		{
			int i;
			for (i = 0; args[i] != 65280; i++)
			{
			}
			return i;
		}

		private void readDevClick(object sender, RoutedEventArgs e)
		{
			doReadDev();
		}

		private void doReadDev()
		{
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Unknown result type (might be due to invalid IL or missing references)
			//IL_0058: Invalid comparison between Unknown and I4
			//IL_0126: Unknown result type (might be due to invalid IL or missing references)
			//IL_0151: Unknown result type (might be due to invalid IL or missing references)
			string text;
			if (!connectStatus)
			{
				needReadDev = 0;
				text = ((FrameworkElement)this).TryFindResource((object)"connect_robot") as string;
				MessageBox.Show(text);
				return;
			}
			needSendDevChangeFlag = false;
			text = ((FrameworkElement)this).TryFindResource((object)"replace_deviation") as string;
			if ((int)MessageBox.Show(text, "Confirmation", (MessageBoxButton)4) != 6)
			{
				return;
			}
			ushort[] array = new ushort[50];
			for (int i = 0; i < 50; i++)
			{
				array[i] = 65280;
			}
			makeAndSendCmd(13, array);
			byte[] array2 = new byte[60];
			if (MyDeviceManagement.ReadReportFromDevice(0, false, ref array2, 300))
			{
				if (array2[0] == 85 && array2[1] == 85 && array2[3] == 13)
				{
					for (int j = 0; j < 6; j++)
					{
						servosViewList[j].CurDev = (sbyte)array2[j + 1 + 4];
					}
					text = ((FrameworkElement)this).TryFindResource((object)"read_success") as string;
					MessageBox.Show(text);
					needReadDev = 2;
					needSendDevChangeFlag = true;
				}
			}
			else
			{
				text = ((FrameworkElement)this).TryFindResource((object)"read_timeout") as string;
				MessageBox.Show(text);
			}
		}

		private void downloadDevClick(object sender, RoutedEventArgs e)
		{
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Invalid comparison between Unknown and I4
			//IL_007e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0084: Invalid comparison between Unknown and I4
			//IL_016f: Unknown result type (might be due to invalid IL or missing references)
			//IL_018c: Unknown result type (might be due to invalid IL or missing references)
			string text;
			if (!connectStatus)
			{
				text = ((FrameworkElement)this).TryFindResource((object)"connect_robot") as string;
				MessageBox.Show(text);
				return;
			}
			text = ((FrameworkElement)this).TryFindResource((object)"download_dev_tips") as string;
			if ((int)MessageBox.Show(text, "Confirmation", (MessageBoxButton)4) != 6)
			{
				return;
			}
			bool flag = false;
			if (!checkDevitation())
			{
				text = ((FrameworkElement)this).TryFindResource((object)"dev_change_tips") as string;
				flag = (((int)MessageBox.Show(text, "Confirmation", (MessageBoxButton)4) == 6) ? true : false);
			}
			else
			{
				flag = true;
			}
			if (!flag)
			{
				return;
			}
			ushort[] array = new ushort[50];
			for (int i = 0; i < 50; i++)
			{
				array[i] = 65280;
			}
			array[0] = 0;
			for (int j = 0; j < 6; j++)
			{
				array[j + 1] = (ushort)servosViewList[j].CurDev;
			}
			makeAndSendCmd(12, array);
			byte[] array2 = new byte[60];
			if (MyDeviceManagement.ReadReportFromDevice(0, false, ref array2, 800))
			{
				if (array2[0] == 85 && array2[1] == 85 && array2[3] == 12)
				{
					text = ((FrameworkElement)this).TryFindResource((object)"operation_success") as string;
					MessageBox.Show(text);
				}
			}
			else
			{
				text = ((FrameworkElement)this).TryFindResource((object)"operation_fail") as string;
				MessageBox.Show(text);
			}
		}

		private void resetDevClick(object sender, RoutedEventArgs e)
		{
			needSendDevChangeFlag = false;
			for (int i = 0; i < servosViewList.Count; i++)
			{
				servosViewList[i].CurDev = 0;
			}
			needSendDevChangeFlag = true;
		}

		private bool checkDevitation()
		{
			int num = 0;
			for (int i = 0; i < servosViewList.Count; i++)
			{
				if (servosViewList[i].CurDev != 0)
				{
					num++;
				}
			}
			if (num > 2)
			{
				return true;
			}
			return false;
		}

		private void openFileClick(object sender, RoutedEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Expected O, but got Unknown
			//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
			OpenFileDialog val = new OpenFileDialog();
			((FileDialog)val).set_DefaultExt(".rob");
			((FileDialog)val).set_Filter("rob file|*.rob");
			if (((CommonDialog)val).ShowDialog() == true)
			{
				filePathTB.set_Text(((FileDialog)val).get_FileName());
				try
				{
					FileStream fileStream = new FileStream(((FileDialog)val).get_FileName(), FileMode.Open);
					fileStream.Seek(0L, SeekOrigin.Begin);
					byte[] array = new byte[fileStream.Length];
					fileStream.Read(array, 0, (int)fileStream.Length);
					setActionList(array);
				}
				catch (IOException)
				{
					string text = ((FrameworkElement)this).TryFindResource((object)"open_file_fail") as string;
					MessageBox.Show(text);
				}
			}
		}

		private void saveFileClick(object sender, RoutedEventArgs e)
		{
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_0031: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Expected O, but got Unknown
			if (((Collection<ServoAction>)(object)m_ServoActions).Count == 0)
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"add_action_tips") as string;
				MessageBox.Show(text);
				return;
			}
			SaveFileDialog val = new SaveFileDialog();
			((FileDialog)val).set_DefaultExt(".rob");
			((FileDialog)val).set_Filter("rob file|*.rob");
			if (((CommonDialog)val).ShowDialog() != true)
			{
				return;
			}
			FileStream fileStream = new FileStream(((FileDialog)val).get_FileName(), FileMode.Create);
			byte[] array = new byte[194 * ((Collection<ServoAction>)(object)m_ServoActions).Count + 16];
			Array.Clear(array, 0, array.Length);
			array[0] = 82;
			array[1] = 79;
			array[2] = 66;
			array[3] = 65;
			array[4] = 82;
			array[5] = 77;
			array[6] = (byte)((uint)((Collection<ServoAction>)(object)m_ServoActions).Count & 0xFFu);
			array[7] = (byte)((uint)(((Collection<ServoAction>)(object)m_ServoActions).Count >> 8) & 0xFFu);
			for (int i = 0; i < ((Collection<ServoAction>)(object)m_ServoActions).Count; i++)
			{
				array[16 + i * 194] = (byte)(((Collection<ServoAction>)(object)m_ServoActions)[i].ServoTime & 0xFFu);
				array[17 + i * 194] = (byte)((uint)(((Collection<ServoAction>)(object)m_ServoActions)[i].ServoTime >> 8) & 0xFFu);
				for (int j = 0; j < 6; j++)
				{
					array[24 + i * 194 + j * 6] = (byte)(((Collection<ServoAction>)(object)m_ServoActions)[i].ServoAngles[j] & 0xFFu);
					array[25 + i * 194 + j * 6] = (byte)((uint)(((Collection<ServoAction>)(object)m_ServoActions)[i].ServoAngles[j] >> 8) & 0xFFu);
				}
			}
			try
			{
				fileStream.Write(array, 0, array.Length);
				fileStream.Flush();
				fileStream.Close();
				needSave = false;
			}
			catch (IOException)
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"operation_fail") as string;
			}
		}

		private void setActionList(byte[] data, bool intergateFlag = false)
		{
			//IL_0096: Unknown result type (might be due to invalid IL or missing references)
			//IL_0185: Unknown result type (might be due to invalid IL or missing references)
			int num = 0;
			if (data[0] == 82 && data[1] == 79 && data[2] == 66 && data[3] == 65 && data[4] == 82 && data[5] == 77)
			{
				ushort num2 = (ushort)(data[7] * 256 + data[6]);
				if (num2 > 0 && !intergateFlag)
				{
					((Collection<ServoAction>)(object)m_ServoActions).Clear();
				}
				if (num2 + ((Collection<ServoAction>)(object)m_ServoActions).Count > 1020)
				{
					string text = ((FrameworkElement)this).TryFindResource((object)"actions_max_tips") as string;
					MessageBox.Show(text);
				}
				num = ((Collection<ServoAction>)(object)m_ServoActions).Count;
				for (ushort num3 = 0; num3 < num2; num3 = (ushort)(num3 + 1))
				{
					ServoAction servoAction = new ServoAction();
					servoAction.ServoTime = (ushort)(data[num3 * 194 + 17] * 256 + data[num3 * 194 + 16]);
					servoAction.ItemID = num3 + 1 + num;
					for (ushort num4 = 0; num4 < 6; num4 = (ushort)(num4 + 1))
					{
						servoAction.ServoAngles.Add((ushort)(data[num3 * 194 + 25 + num4 * 6] * 256 + data[num3 * 194 + 24 + num4 * 6]));
					}
					((Collection<ServoAction>)(object)m_ServoActions).Add(servoAction);
				}
				setActionListSelectRow(0);
			}
			else
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"file_damage") as string;
				MessageBox.Show(text);
			}
		}

		private void integrateClick(object sender, RoutedEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Expected O, but got Unknown
			//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
			OpenFileDialog val = new OpenFileDialog();
			((FileDialog)val).set_DefaultExt(".rob");
			((FileDialog)val).set_Filter("rob file|*.rob");
			if (((CommonDialog)val).ShowDialog() == true)
			{
				filePathTB.set_Text(((FileDialog)val).get_FileName());
				try
				{
					FileStream fileStream = new FileStream(((FileDialog)val).get_FileName(), FileMode.Open);
					fileStream.Seek(0L, SeekOrigin.Begin);
					byte[] array = new byte[fileStream.Length];
					fileStream.Read(array, 0, (int)fileStream.Length);
					setActionList(array, intergateFlag: true);
					needSave = true;
				}
				catch (IOException)
				{
					string text = ((FrameworkElement)this).TryFindResource((object)"open_file_fail") as string;
					MessageBox.Show(text);
				}
			}
		}

		private void downloadClick(object sender, RoutedEventArgs e)
		{
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_0055: Unknown result type (might be due to invalid IL or missing references)
			//IL_008b: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_0381: Unknown result type (might be due to invalid IL or missing references)
			//IL_0580: Unknown result type (might be due to invalid IL or missing references)
			//IL_065f: Unknown result type (might be due to invalid IL or missing references)
			//IL_067c: Unknown result type (might be due to invalid IL or missing references)
			if (!connectStatus)
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"connect_robot") as string;
				MessageBox.Show(text);
				return;
			}
			if (((Collection<ServoAction>)(object)m_ServoActions).Count == 0)
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"add_action_first") as string;
				MessageBox.Show(text);
				return;
			}
			if (((Collection<ServoAction>)(object)m_ServoActions).Count > 1020)
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"actions_max_tips") as string;
				MessageBox.Show(text);
				return;
			}
			((UIElement)downloadBtn).set_IsEnabled(false);
			int num = ((((Collection<ServoAction>)(object)m_ServoActions).Count % 255 == 0) ? (((Collection<ServoAction>)(object)m_ServoActions).Count / 255) : (((Collection<ServoAction>)(object)m_ServoActions).Count / 255 + 1));
			ushort[] array = new ushort[50];
			for (int i = 0; i < 50; i++)
			{
				array[i] = 65280;
			}
			array[0] = 1;
			array[1] = (byte)((Selector)actionGroupCombox).get_SelectedIndex();
			for (int j = 0; j < num; j++)
			{
				if (j == num - 1)
				{
					array[2 + j] = (byte)(((Collection<ServoAction>)(object)m_ServoActions).Count - 255 * (num - 1));
				}
				else if (num > 1)
				{
					array[2 + j] = 255;
				}
			}
			makeAndSendCmd(5, array);
			byte[] array2 = new byte[60];
			if (MyDeviceManagement.ReadReportFromDevice(0, false, ref array2, 800))
			{
				if (array2[0] == 85 && array2[1] == 85 && array2[2] == 4 && array2[3] == 5 && array2[4] == 1)
				{
				}
				for (int k = 0; k < 50; k++)
				{
					array[k] = 65280;
				}
				array[0] = 2;
				array[1] = (byte)((Selector)actionGroupCombox).get_SelectedIndex();
				array[2] = (byte)num;
				array[3] = 0;
				makeAndSendCmd(5, array);
				if (MyDeviceManagement.ReadReportFromDevice(0, false, ref array2, 800))
				{
					if (array2[0] == 85 && array2[1] == 85 && array2[2] == 4 && array2[3] == 5 && array2[4] == 2)
					{
					}
					for (int l = 0; l < 50; l++)
					{
						array[l] = 65280;
					}
					array[0] = 3;
					array[1] = (byte)((Selector)actionGroupCombox).get_SelectedIndex();
					array[2] = 0;
					for (int m = 0; m < num; m++)
					{
						array[3 + m] = (byte)m;
					}
					makeAndSendCmd(5, array);
					if (MyDeviceManagement.ReadReportFromDevice(0, false, ref array2, 800))
					{
						if (array2[0] == 85 && array2[1] == 85 && array2[2] == 4 && array2[3] == 5 && array2[4] == 3)
						{
						}
						int num2 = 0;
						for (int n = 0; n < num; n++)
						{
							if (n == num - 1)
							{
								num2 = ((Collection<ServoAction>)(object)m_ServoActions).Count - 255 * (num - 1);
							}
							else if (num > 1)
							{
								num2 = 255;
							}
							for (int num3 = 0; num3 < num2; num3++)
							{
								for (int num4 = 0; num4 < 50; num4++)
								{
									array[num4] = 65280;
								}
								array[0] = 4;
								array[1] = (byte)((Selector)actionGroupCombox).get_SelectedIndex();
								array[2] = (byte)n;
								array[3] = (byte)num3;
								array[4] = 11;
								array[5] = (byte)(((Collection<ServoAction>)(object)m_ServoActions)[num3 + n * 255].ServoTime & 0xFFu);
								array[6] = (byte)((uint)(((Collection<ServoAction>)(object)m_ServoActions)[num3 + n * 255].ServoTime >> 8) & 0xFFu);
								setActionListSelectRow(num3 + n * 255);
								for (ushort num5 = 0; num5 < 6; num5 = (ushort)(num5 + 1))
								{
									array[7 + 3 * num5] = (byte)(num5 + 1);
									array[8 + 3 * num5] = (byte)(((Collection<ServoAction>)(object)m_ServoActions)[num3 + n * 255].ServoAngles[num5] & 0xFFu);
									array[9 + 3 * num5] = (byte)((uint)(((Collection<ServoAction>)(object)m_ServoActions)[num3 + n * 255].ServoAngles[num5] >> 8) & 0xFFu);
								}
								makeAndSendCmd(5, array);
								if (MyDeviceManagement.ReadReportFromDevice(0, false, ref array2, 800))
								{
									if (array2[0] == 85 && array2[1] == 85 && array2[2] == 4 && array2[3] == 5 && array2[4] == 4)
									{
									}
									continue;
								}
								string text = ((FrameworkElement)this).TryFindResource((object)"download_wait_timeout") as string;
								MessageBox.Show(text);
								((UIElement)downloadBtn).set_IsEnabled(true);
								return;
							}
						}
						for (int num6 = 0; num6 < 50; num6++)
						{
							array[num6] = 65280;
						}
						array[0] = 5;
						array[1] = (byte)((Selector)actionGroupCombox).get_SelectedIndex();
						makeAndSendCmd(5, array);
						if (MyDeviceManagement.ReadReportFromDevice(0, false, ref array2, 800))
						{
							if (array2[0] == 85 && array2[1] == 85 && array2[2] == 4 && array2[3] == 5)
							{
								string text = ((FrameworkElement)this).TryFindResource((object)"download_success") as string;
								((UIElement)downloadBtn).set_IsEnabled(true);
								MessageBox.Show(text);
							}
						}
						else
						{
							string text = ((FrameworkElement)this).TryFindResource((object)"download_wait_timeout") as string;
							MessageBox.Show(text);
							((UIElement)downloadBtn).set_IsEnabled(true);
						}
					}
					else
					{
						string text = ((FrameworkElement)this).TryFindResource((object)"download_wait_timeout") as string;
						MessageBox.Show(text);
						((UIElement)downloadBtn).set_IsEnabled(true);
					}
				}
				else
				{
					string text = ((FrameworkElement)this).TryFindResource((object)"download_wait_timeout") as string;
					MessageBox.Show(text);
					((UIElement)downloadBtn).set_IsEnabled(true);
				}
			}
			else
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"download_wait_timeout") as string;
				MessageBox.Show(text);
				((UIElement)downloadBtn).set_IsEnabled(true);
			}
		}

		private void allEraseClick(object sender, RoutedEventArgs e)
		{
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Invalid comparison between Unknown and I4
			//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_010a: Unknown result type (might be due to invalid IL or missing references)
			string text;
			if (!connectStatus)
			{
				text = ((FrameworkElement)this).TryFindResource((object)"connect_robot") as string;
				MessageBox.Show(text);
				return;
			}
			text = ((FrameworkElement)this).TryFindResource((object)"comfirm_all_erase") as string;
			if ((int)MessageBox.Show(text, "Confirmation", (MessageBoxButton)4) != 6)
			{
				return;
			}
			ushort[] array = new ushort[50];
			for (int i = 0; i < 50; i++)
			{
				array[i] = 65280;
			}
			array[0] = 255;
			makeAndSendCmd(8, array);
			byte[] array2 = new byte[60];
			if (MyDeviceManagement.ReadReportFromDevice(0, false, ref array2, 800))
			{
				if (array2[0] == 85 && array2[1] == 85 && array2[2] == 2 && array2[3] == 8)
				{
					text = ((FrameworkElement)this).TryFindResource((object)"erase_success") as string;
					MessageBox.Show(text);
				}
			}
			else
			{
				text = ((FrameworkElement)this).TryFindResource((object)"erase_fail") as string;
				MessageBox.Show(text);
			}
		}

		private void runActionClick(object sender, RoutedEventArgs e)
		{
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			if (!connectStatus)
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"connect_robot") as string;
				MessageBox.Show(text);
				return;
			}
			ushort[] array = new ushort[50];
			for (int i = 0; i < 50; i++)
			{
				array[i] = 65280;
			}
			array[0] = (byte)((Selector)actionGroupCombox).get_SelectedIndex();
			array[1] = 1;
			array[2] = 0;
			makeAndSendCmd(6, array);
		}

		private void stopClick(object sender, RoutedEventArgs e)
		{
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			if (!connectStatus)
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"connect_robot") as string;
				MessageBox.Show(text);
				return;
			}
			ushort[] array = new ushort[50];
			for (int i = 0; i < 50; i++)
			{
				array[i] = 65280;
			}
			array[0] = 7;
			makeAndSendCmd(7, array);
		}

		private void singleEraseClick(object sender, RoutedEventArgs e)
		{
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Invalid comparison between Unknown and I4
			//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_0111: Unknown result type (might be due to invalid IL or missing references)
			string text;
			if (!connectStatus)
			{
				text = ((FrameworkElement)this).TryFindResource((object)"connect_robot") as string;
				MessageBox.Show(text);
				return;
			}
			text = ((FrameworkElement)this).TryFindResource((object)"comfirm_single_erase") as string;
			if ((int)MessageBox.Show(text, "Confirmation", (MessageBoxButton)4) != 6)
			{
				return;
			}
			ushort[] array = new ushort[50];
			for (int i = 0; i < 50; i++)
			{
				array[i] = 65280;
			}
			array[0] = (byte)((Selector)actionGroupCombox).get_SelectedIndex();
			makeAndSendCmd(8, array);
			byte[] array2 = new byte[60];
			if (MyDeviceManagement.ReadReportFromDevice(0, false, ref array2, 800))
			{
				if (array2[0] == 85 && array2[1] == 85 && array2[2] == 2 && array2[3] == 8)
				{
					text = ((FrameworkElement)this).TryFindResource((object)"erase_success") as string;
					MessageBox.Show(text);
				}
			}
			else
			{
				text = ((FrameworkElement)this).TryFindResource((object)"erase_fail") as string;
				MessageBox.Show(text);
			}
		}

		private void resetServoClick(object sender, RoutedEventArgs e)
		{
			needSendAngelChangeFlag = false;
			ushort[] array = new ushort[50];
			for (int i = 0; i < 50; i++)
			{
				array[i] = 65280;
			}
			array[0] = 6;
			array[1] = 232;
			array[2] = 3;
			for (int j = 0; j < 6; j++)
			{
				array[3 + 3 * j] = (byte)(j + 1);
				array[4 + 3 * j] = 220;
				array[5 + 3 * j] = 5;
				servosViewList[j].CurAngle = 1500;
			}
			makeAndSendCmd(3, array);
			needSendAngelChangeFlag = true;
		}

		private void languageChange(object sender, SelectionChangedEventArgs e)
		{
			//IL_013b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0145: Expected O, but got Unknown
			ResourceDictionary val = null;
			ComboBox val2 = sender as ComboBox;
			if (((Selector)val2).get_SelectedIndex() == 2)
			{
				((UIElement)releaseTips).set_Visibility((Visibility)0);
				((UIElement)closeTips).set_Visibility((Visibility)0);
				((UIElement)forwardTips).set_Visibility((Visibility)0);
				((UIElement)backwardTips).set_Visibility((Visibility)0);
				((UIElement)downTips).set_Visibility((Visibility)0);
				((UIElement)upTips).set_Visibility((Visibility)0);
				((UIElement)leftTips).set_Visibility((Visibility)0);
				((UIElement)rightTips).set_Visibility((Visibility)0);
			}
			else
			{
				((UIElement)releaseTips).set_Visibility((Visibility)2);
				((UIElement)closeTips).set_Visibility((Visibility)2);
				((UIElement)forwardTips).set_Visibility((Visibility)2);
				((UIElement)backwardTips).set_Visibility((Visibility)2);
				((UIElement)downTips).set_Visibility((Visibility)2);
				((UIElement)upTips).set_Visibility((Visibility)2);
				((UIElement)leftTips).set_Visibility((Visibility)2);
				((UIElement)rightTips).set_Visibility((Visibility)2);
			}
			object obj = Application.LoadComponent(new Uri("Language\\" + ((Selector)val2).get_SelectedIndex() switch
			{
				0 => "zh-CN", 
				1 => "zh-TW", 
				2 => "DefaultLanguage", 
				_ => "DefaultLanguage", 
			} + ".xaml", (UriKind)2));
			val = obj as ResourceDictionary;
			if (val != null)
			{
				if (((FrameworkElement)this).get_Resources().get_MergedDictionaries().Count > 0)
				{
					((FrameworkElement)this).get_Resources().get_MergedDictionaries().Clear();
				}
				((FrameworkElement)this).get_Resources().get_MergedDictionaries().Add(val);
			}
			updateServoText();
		}

		private void runOnlineClick(object sender, RoutedEventArgs e)
		{
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ad: Expected O, but got Unknown
			//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b2: Expected O, but got Unknown
			//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f2: Expected O, but got Unknown
			//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f7: Expected O, but got Unknown
			if (!connectStatus)
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"connect_robot") as string;
				MessageBox.Show(text);
			}
			else if (((Collection<ServoAction>)(object)m_ServoActions).Count == 0)
			{
				string text = ((FrameworkElement)this).TryFindResource((object)"add_action_first") as string;
				MessageBox.Show(text);
			}
			else if (!runningOnline)
			{
				runningOnline = true;
				stopWatch.Restart();
				_1msTimer.Start();
				curRunId = 0;
				runAtCurrentItem(0);
				runonlineImag.set_Source((ImageSource)new BitmapImage(new Uri("/Resources/stop.png", (UriKind)2)));
			}
			else
			{
				runningOnline = false;
				_1msTimer.Stop();
				stopWatch.Stop();
				curRunId = 0;
				runonlineImag.set_Source((ImageSource)new BitmapImage(new Uri("/Resources/onlinerun.png", (UriKind)2)));
			}
		}

		private void runAtCurrentItem(int index)
		{
			needSendAngelChangeFlag = false;
			sendActionAngleCmd(index);
			setActionListSelectRow(index);
			needSendAngelChangeFlag = true;
		}

		public void runOnlineHandler(object sender, EventArgs e)
		{
			if (stopWatch.get_ElapsedMilliseconds() < ((Collection<ServoAction>)(object)m_ServoActions)[curRunId].ServoTime)
			{
				return;
			}
			if (curRunId == ((Collection<ServoAction>)(object)m_ServoActions).Count - 1)
			{
				Task.Factory.StartNew(delegate
				{
					runOver();
				}, new CancellationTokenSource().Token, TaskCreationOptions.None, _syncContextTaskScheduler).Wait();
				return;
			}
			stopWatch.Restart();
			Task.Factory.StartNew(delegate
			{
				runAtCurrentItem(++curRunId);
			}, new CancellationTokenSource().Token, TaskCreationOptions.None, _syncContextTaskScheduler).Wait();
		}

		private void runOver()
		{
			//IL_0039: Unknown result type (might be due to invalid IL or missing references)
			//IL_0043: Expected O, but got Unknown
			//IL_003e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Expected O, but got Unknown
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b7: Expected O, but got Unknown
			//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bc: Expected O, but got Unknown
			//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
			_1msTimer.Stop();
			stopWatch.Stop();
			if (!connectStatus)
			{
				runningOnline = false;
				runonlineImag.set_Source((ImageSource)new BitmapImage(new Uri("/Resources/onlinerun.png", (UriKind)2)));
				MessageBox.Show("连接断开，停止运行");
			}
			else if (((ToggleButton)loopCheck).get_IsChecked().Value)
			{
				stopWatch.Restart();
				_1msTimer.Start();
				curRunId = 0;
				runAtCurrentItem(0);
			}
			else
			{
				runningOnline = false;
				runonlineImag.set_Source((ImageSource)new BitmapImage(new Uri("/Resources/onlinerun.png", (UriKind)2)));
				MessageBox.Show("运行结束");
			}
		}

		private void showSaveTips(bool flag = true)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Expected O, but got Unknown
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			DoubleAnimation val = new DoubleAnimation();
			val.set_From((double?)0.0);
			val.set_To((double?)430.0);
			Duration duration = default(Duration);
			((Duration)(ref duration))._002Ector(TimeSpan.FromMilliseconds(5000.0));
			((Timeline)val).set_Duration(duration);
			((Timeline)val).set_AutoReverse(true);
			((Timeline)val).set_RepeatBehavior(RepeatBehavior.get_Forever());
			((Animatable)tipsTranslate).BeginAnimation(TranslateTransform.XProperty, (AnimationTimeline)(object)val);
		}

		public void timeCycle(object sender, EventArgs e)
		{
			if (needSave)
			{
				needSaveCnt++;
				if (needSaveCnt >= 300)
				{
					needSaveCnt = 0u;
					((UIElement)saveFileTB).set_Visibility((Visibility)0);
				}
			}
			else
			{
				needSaveCnt = 0u;
				((UIElement)saveFileTB).set_Visibility((Visibility)2);
			}
			if (readDevStart)
			{
				readDevStartCnt++;
				if (readDevStartCnt > 3)
				{
					readDevStartCnt = 0;
					needReadDev = 0;
					readDevStart = false;
				}
			}
			else
			{
				readDevStartCnt = 0;
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			//IL_001b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0021: Expected O, but got Unknown
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri val = new Uri("/LeArm;component/mainwindow.xaml", (UriKind)2);
				Application.LoadComponent((object)this, val);
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c4: Expected O, but got Unknown
			//IL_0113: Unknown result type (might be due to invalid IL or missing references)
			//IL_011d: Expected O, but got Unknown
			//IL_0124: Unknown result type (might be due to invalid IL or missing references)
			//IL_012e: Expected O, but got Unknown
			//IL_013b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0145: Expected O, but got Unknown
			//IL_014d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0157: Expected O, but got Unknown
			//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ce: Expected O, but got Unknown
			//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
			//IL_01df: Expected O, but got Unknown
			//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f0: Expected O, but got Unknown
			//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0201: Expected O, but got Unknown
			//IL_0208: Unknown result type (might be due to invalid IL or missing references)
			//IL_0212: Expected O, but got Unknown
			//IL_0219: Unknown result type (might be due to invalid IL or missing references)
			//IL_0223: Expected O, but got Unknown
			//IL_022a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0234: Expected O, but got Unknown
			//IL_023b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0245: Expected O, but got Unknown
			//IL_024c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0256: Expected O, but got Unknown
			//IL_025d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0267: Expected O, but got Unknown
			//IL_0274: Unknown result type (might be due to invalid IL or missing references)
			//IL_027e: Expected O, but got Unknown
			//IL_0286: Unknown result type (might be due to invalid IL or missing references)
			//IL_0290: Expected O, but got Unknown
			//IL_029d: Unknown result type (might be due to invalid IL or missing references)
			//IL_02a7: Expected O, but got Unknown
			//IL_02af: Unknown result type (might be due to invalid IL or missing references)
			//IL_02b9: Expected O, but got Unknown
			//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_02d0: Expected O, but got Unknown
			//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
			//IL_02e2: Expected O, but got Unknown
			//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_02f9: Expected O, but got Unknown
			//IL_0301: Unknown result type (might be due to invalid IL or missing references)
			//IL_030b: Expected O, but got Unknown
			//IL_0312: Unknown result type (might be due to invalid IL or missing references)
			//IL_031c: Expected O, but got Unknown
			//IL_0323: Unknown result type (might be due to invalid IL or missing references)
			//IL_032d: Expected O, but got Unknown
			//IL_0334: Unknown result type (might be due to invalid IL or missing references)
			//IL_033e: Expected O, but got Unknown
			//IL_034b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0355: Expected O, but got Unknown
			//IL_035d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0367: Expected O, but got Unknown
			//IL_0374: Unknown result type (might be due to invalid IL or missing references)
			//IL_037e: Expected O, but got Unknown
			//IL_0386: Unknown result type (might be due to invalid IL or missing references)
			//IL_0390: Expected O, but got Unknown
			//IL_039d: Unknown result type (might be due to invalid IL or missing references)
			//IL_03a7: Expected O, but got Unknown
			//IL_03af: Unknown result type (might be due to invalid IL or missing references)
			//IL_03b9: Expected O, but got Unknown
			//IL_03bf: Unknown result type (might be due to invalid IL or missing references)
			//IL_03cb: Unknown result type (might be due to invalid IL or missing references)
			//IL_03d5: Expected O, but got Unknown
			//IL_03dd: Unknown result type (might be due to invalid IL or missing references)
			//IL_03e7: Expected O, but got Unknown
			//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0403: Expected O, but got Unknown
			//IL_040b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0415: Expected O, but got Unknown
			//IL_0422: Unknown result type (might be due to invalid IL or missing references)
			//IL_042c: Expected O, but got Unknown
			//IL_0434: Unknown result type (might be due to invalid IL or missing references)
			//IL_043e: Expected O, but got Unknown
			//IL_044b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0455: Expected O, but got Unknown
			//IL_045d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0467: Expected O, but got Unknown
			//IL_0474: Unknown result type (might be due to invalid IL or missing references)
			//IL_047e: Expected O, but got Unknown
			//IL_0486: Unknown result type (might be due to invalid IL or missing references)
			//IL_0490: Expected O, but got Unknown
			//IL_0497: Unknown result type (might be due to invalid IL or missing references)
			//IL_04a1: Expected O, but got Unknown
			//IL_04ae: Unknown result type (might be due to invalid IL or missing references)
			//IL_04b8: Expected O, but got Unknown
			//IL_04bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_04c8: Unknown result type (might be due to invalid IL or missing references)
			//IL_04d2: Expected O, but got Unknown
			//IL_04d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_04e2: Unknown result type (might be due to invalid IL or missing references)
			//IL_04ec: Expected O, but got Unknown
			//IL_04f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_04fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0506: Expected O, but got Unknown
			//IL_050a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0516: Unknown result type (might be due to invalid IL or missing references)
			//IL_0520: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				actionList = (DataGrid)target;
				actionList.add_CurrentCellChanged((EventHandler<EventArgs>)onCellChange);
				actionList.add_CellEditEnding((EventHandler<DataGridCellEditEndingEventArgs>)editAngleEnd);
				actionList.add_BeginningEdit((EventHandler<DataGridBeginningEditEventArgs>)editAngleBegin);
				break;
			case 2:
				servosView = (Canvas)target;
				break;
			case 3:
				lanSetComBox = (ComboBox)target;
				((Selector)lanSetComBox).add_SelectionChanged(new SelectionChangedEventHandler(languageChange));
				break;
			case 4:
				connectImag = (Image)target;
				break;
			case 5:
				servo1 = (ServoView)target;
				break;
			case 6:
				servo2 = (ServoView)target;
				break;
			case 7:
				servo3 = (ServoView)target;
				break;
			case 8:
				servo4 = (ServoView)target;
				break;
			case 9:
				servo5 = (ServoView)target;
				break;
			case 10:
				servo6 = (ServoView)target;
				break;
			case 11:
				releaseTips = (TextBlock)target;
				break;
			case 12:
				closeTips = (TextBlock)target;
				break;
			case 13:
				forwardTips = (TextBlock)target;
				break;
			case 14:
				backwardTips = (TextBlock)target;
				break;
			case 15:
				downTips = (TextBlock)target;
				break;
			case 16:
				upTips = (TextBlock)target;
				break;
			case 17:
				leftTips = (TextBlock)target;
				break;
			case 18:
				rightTips = (TextBlock)target;
				break;
			case 19:
				actTimeTX = (TextBox)target;
				break;
			case 20:
				addActionBtn = (Button)target;
				((ButtonBase)addActionBtn).add_Click(new RoutedEventHandler(addAction));
				break;
			case 21:
				deleteActionBtn = (Button)target;
				((ButtonBase)deleteActionBtn).add_Click(new RoutedEventHandler(deleteAction));
				break;
			case 22:
				updateActionBtn = (Button)target;
				((ButtonBase)updateActionBtn).add_Click(new RoutedEventHandler(updateAction));
				break;
			case 23:
				insertActionBtn = (Button)target;
				((ButtonBase)insertActionBtn).add_Click(new RoutedEventHandler(insertAction));
				break;
			case 24:
				saveFileTB = (TextBlock)target;
				break;
			case 25:
				tipsTranslate = (TranslateTransform)target;
				break;
			case 26:
				filePathTB = (TextBlock)target;
				break;
			case 27:
				readDevBtn = (Button)target;
				((ButtonBase)readDevBtn).add_Click(new RoutedEventHandler(readDevClick));
				break;
			case 28:
				downloadDevBtn = (Button)target;
				((ButtonBase)downloadDevBtn).add_Click(new RoutedEventHandler(downloadDevClick));
				break;
			case 29:
				resetDevBtn = (Button)target;
				((ButtonBase)resetDevBtn).add_Click(new RoutedEventHandler(resetDevClick));
				break;
			case 30:
				loopCheck = (CheckBox)target;
				break;
			case 31:
				((ButtonBase)(Button)target).add_Click(new RoutedEventHandler(runOnlineClick));
				break;
			case 32:
				runonlineImag = (Image)target;
				break;
			case 33:
				((ButtonBase)(Button)target).add_Click(new RoutedEventHandler(resetServoClick));
				break;
			case 34:
				openFileBtn = (Button)target;
				((ButtonBase)openFileBtn).add_Click(new RoutedEventHandler(openFileClick));
				break;
			case 35:
				saveFileBtn = (Button)target;
				((ButtonBase)saveFileBtn).add_Click(new RoutedEventHandler(saveFileClick));
				break;
			case 36:
				integrateBtn = (Button)target;
				((ButtonBase)integrateBtn).add_Click(new RoutedEventHandler(integrateClick));
				break;
			case 37:
				actionGroupCombox = (ComboBox)target;
				break;
			case 38:
				downloadBtn = (Button)target;
				((ButtonBase)downloadBtn).add_Click(new RoutedEventHandler(downloadClick));
				break;
			case 39:
				((ButtonBase)(Button)target).add_Click(new RoutedEventHandler(singleEraseClick));
				break;
			case 40:
				((ButtonBase)(Button)target).add_Click(new RoutedEventHandler(allEraseClick));
				break;
			case 41:
				((ButtonBase)(Button)target).add_Click(new RoutedEventHandler(runActionClick));
				break;
			case 42:
				((ButtonBase)(Button)target).add_Click(new RoutedEventHandler(stopClick));
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
}
